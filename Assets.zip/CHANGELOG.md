## 1.0.4
* Replaced Eclipse 7 (Enemy cooldowns -50%) with Activate a Random Artifact every Stage
* View readme for explanations on some artifact changes
* Eclipse 4 now also reduces enemy cooldowns by 25%
* Made Eclipse 1 slightly harder
* Eclipse 5 Enemy damage reduced to +40% from +50%

## 1.0.3
* Eclipse 6 now only gives enemies 50% more damage and not health

## 1.0.1
* Fixed dependencies
* nerfed eclipse 3 in the provi fight

## 1.0.0
* Initial release