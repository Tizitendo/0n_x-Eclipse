# Onyx-Eclipse

- Adds the cut Eclipse gamemode back into the game
1) StageStart, Director Credits: +500%
2) Teleporter Gains Radius
3) Enemies Can Spawn After TP Event
4) Enemy Speed: +25%
5) Chest Prices: +60%
6) Enemy Health/Damage: +40%
7) Every Stage, Activate a Random Artifact
8) Allies receive permanent damage
9) ???

Artifacts:
- Honor: Enemies drop 50% more gold and xp, can't spawn bligtheds
- Sacrifice: Item drop rate lowered with every item dropped this stage

## Special Thanks To
* The Return Of Modding Discord, Especially @Kris, @Klehrik and @syntaxevasion

## Contact
For questions or bug reports, you can find us in the [RoRR Modding Server](https://discord.gg/VjS57cszMq) @Onyx
